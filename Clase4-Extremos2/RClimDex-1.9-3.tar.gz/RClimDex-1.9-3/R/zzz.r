.onAttach <- function(lib, pkg) {
  packageStartupMessage("\nRClimDex 1.9\nUse rclimdex.start() to launch or re-launch the interface.\n")
}
